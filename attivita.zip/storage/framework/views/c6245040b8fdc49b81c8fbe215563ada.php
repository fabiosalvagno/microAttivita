<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Pannello di Controllo')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <h1 class="text-3xl font-bold text-gray-800 mb-6">Menu Insegnante</h1>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
                        <a href="<?php echo e(route('attivita.create')); ?>" class="block p-6 bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow transition-colors">
                            <h3 class="text-xl font-bold mb-2">Crea Nuova Attività</h3>
                            <p class="text-blue-100">Crea una nuova attività (Scelta Multipla, Vero/Falso, Ascolto).</p>
                        </a>
                        
                        <a href="<?php echo e(route('attivita.index')); ?>" class="block p-6 bg-gray-600 hover:bg-gray-700 text-white rounded-lg shadow transition-colors">
                            <h3 class="text-xl font-bold mb-2">Visualizza Attività</h3>
                            <p class="text-gray-100">Gestisci le tue attività e vedi i risultati.</p>
                        </a>

                        <a href="<?php echo e(route('audio.index')); ?>" class="block p-6 bg-purple-600 hover:bg-purple-700 text-white rounded-lg shadow transition-colors">
                            <h3 class="text-xl font-bold mb-2">Libreria Audio</h3>
                            <p class="text-purple-100">Carica i file audio da usare nelle tue attività.</p>
                        </a>

                        <a href="<?php echo e(route('classes.index')); ?>" class="block p-6 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg shadow transition-colors">
                            <h3 class="text-xl font-bold mb-2">Gestione Classi (Upload)</h3>
                            <p class="text-indigo-100">Crea classi e ottieni i QR code per far caricare i file agli studenti.</p>
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\fabio\OneDrive\Desktop\laravel\attivita\resources\views/dashboard.blade.php ENDPATH**/ ?>